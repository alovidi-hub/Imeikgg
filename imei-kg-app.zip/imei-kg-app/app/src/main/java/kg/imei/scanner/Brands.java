package kg.imei.scanner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Производители устройств: определение по тексту ответа сайта и данные для значка
 * (цветной кружок с короткой меткой — это не логотипы, а собственные обозначения приложения).
 */
public final class Brands {

    public static class Brand {
        public final String name;     // название, которое хранится в истории
        public final String label;    // короткая метка на значке
        public final int color;       // цвет кружка
        public final int textColor;   // цвет метки
        final Pattern pattern;        // по чему искать в тексте

        Brand(String name, String label, int color, int textColor, String regex) {
            this.name = name;
            this.label = label;
            this.color = color;
            this.textColor = textColor;
            this.pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        }
    }

    private static final int WHITE = 0xFFFFFFFF;

    public static final List<Brand> ALL = Arrays.asList(
            new Brand("Samsung", "S", 0xFF1428A0, WHITE, "samsung|galaxy|самсунг"),
            new Brand("Apple", "A", 0xFF424242, WHITE, "apple|iphone|ipad|эппл|айфон"),
            new Brand("Xiaomi", "Mi", 0xFFFF6900, WHITE,
                    "xiaomi|redmi|(?<![a-z])poco(?![a-z])|сяоми|ксиаоми|редми"),
            new Brand("Huawei", "H", 0xFFC8102E, WHITE, "huawei|хуавей|хуавэй"),
            new Brand("Honor", "Ho", 0xFF1F6BFF, WHITE, "(?<![a-z])honor(?![a-z])|хонор"),
            new Brand("Oppo", "O", 0xFF1B9B6B, WHITE, "oppo|оппо"),
            new Brand("Vivo", "V", 0xFF415FFF, WHITE, "(?<![a-z])vivo(?![a-z])|виво"),
            new Brand("Realme", "R", 0xFFFFD400, 0xFF212121, "realme|реалми"),
            new Brand("OnePlus", "1+", 0xFFEB0028, WHITE, "oneplus|one plus|ванплас"),
            new Brand("Tecno", "T", 0xFF0057B8, WHITE, "tecno|текно"),
            new Brand("Infinix", "In", 0xFF2E9E4F, WHITE, "infinix|инфиникс"),
            new Brand("Itel", "i", 0xFFE31B23, WHITE, "(?<![a-z])itel(?![a-z])|итэл|ител"),
            new Brand("Nokia", "N", 0xFF124191, WHITE, "nokia|hmd global|нокиа"),
            new Brand("Motorola", "M", 0xFF00549E, WHITE,
                    "motorola|(?<![a-z])moto(?![a-z])|моторола"),
            new Brand("Sony", "So", 0xFF212121, WHITE, "sony|xperia|сони"),
            new Brand("LG", "LG", 0xFFA50034, WHITE, "(?<![a-z])lg(?![a-z])"),
            new Brand("Google", "G", 0xFF4285F4, WHITE, "(?<![a-z])google(?![a-z])|pixel"),
            new Brand("ZTE", "Z", 0xFF0A6EBD, WHITE, "(?<![a-z])zte(?![a-z])|nubia"),
            new Brand("Lenovo", "L", 0xFFE2231A, WHITE, "lenovo|леново"),
            new Brand("Asus", "As", 0xFF00539B, WHITE, "asus|zenfone|асус"),
            new Brand("Meizu", "Mz", 0xFF1E9BEA, WHITE, "meizu|мейзу"),
            new Brand("Nothing", "No", 0xFF37474F, WHITE, "nothing phone"),
            new Brand("Alcatel", "Al", 0xFF00A3E0, WHITE, "alcatel|алкатель")
    );

    // «Производитель: Samsung», «Марка - Xiaomi» и т.п.
    private static final Pattern LABELED = Pattern.compile(
            "(?:производитель|марка|бренд|өндүрүүчү|өндүрүүчүсү|брэнд|brand|manufacturer|vendor|maker)\\s*[:\\-–—]\\s*([^\\n]+)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    private Brands() {
    }

    /** Возвращает название производителя из текста ответа сайта или "" если не найден. */
    public static String detect(String text) {
        if (text == null || text.isEmpty()) return "";
        Matcher m = LABELED.matcher(text);
        while (m.find()) {
            String b = earliest(m.group(1));
            if (!b.isEmpty()) return b;
        }
        return earliest(text);
    }

    public static Brand get(String name) {
        if (name == null || name.isEmpty()) return null;
        for (Brand b : ALL) {
            if (b.name.equals(name)) return b;
        }
        return null;
    }

    public static List<String> names() {
        List<String> list = new ArrayList<>();
        for (Brand b : ALL) list.add(b.name);
        return list;
    }

    /** Из нескольких найденных производителей берём того, что встречается в тексте раньше всех. */
    private static String earliest(String s) {
        Brand best = null;
        int bestPos = Integer.MAX_VALUE;
        for (Brand b : ALL) {
            Matcher m = b.pattern.matcher(s);
            if (m.find() && m.start() < bestPos) {
                best = b;
                bestPos = m.start();
            }
        }
        return best == null ? "" : best.name;
    }
}
