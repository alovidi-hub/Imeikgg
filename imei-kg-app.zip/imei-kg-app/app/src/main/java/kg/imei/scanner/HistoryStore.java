package kg.imei.scanner;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Хранилище истории проверок (SharedPreferences, JSON). Новые записи — в начале списка. */
public final class HistoryStore {

    public static final int STATUS_UNKNOWN = -1;
    public static final int STATUS_NOT_REGISTERED = 0;
    public static final int STATUS_REGISTERED = 1;

    private static final String PREFS = "history";
    private static final String KEY = "items";
    private static final int MAX_ITEMS = 500;

    public static class Entry {
        public String imei;
        public int status;
        public long time;   // точное время проверки, мс с 1970 года
        public String text; // фрагмент ответа сайта
    }

    private HistoryStore() {
    }

    public static synchronized List<Entry> load(Context c) {
        List<Entry> list = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs(c).getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Entry e = new Entry();
                e.imei = o.optString("imei");
                e.status = o.optInt("status", STATUS_UNKNOWN);
                e.time = o.optLong("time");
                e.text = o.optString("text");
                list.add(e);
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    public static synchronized void add(Context c, Entry entry) {
        List<Entry> list = load(c);
        list.add(0, entry);
        while (list.size() > MAX_ITEMS) list.remove(list.size() - 1);
        save(c, list);
    }

    public static synchronized void remove(Context c, Entry entry) {
        List<Entry> list = load(c);
        for (int i = 0; i < list.size(); i++) {
            Entry e = list.get(i);
            if (e.time == entry.time && e.imei.equals(entry.imei)) {
                list.remove(i);
                break;
            }
        }
        save(c, list);
    }

    public static synchronized void clear(Context c) {
        prefs(c).edit().remove(KEY).apply();
    }

    private static void save(Context c, List<Entry> list) {
        try {
            JSONArray arr = new JSONArray();
            for (Entry e : list) {
                JSONObject o = new JSONObject();
                o.put("imei", e.imei);
                o.put("status", e.status);
                o.put("time", e.time);
                o.put("text", e.text == null ? "" : e.text);
                arr.put(o);
            }
            prefs(c).edit().putString(KEY, arr.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
