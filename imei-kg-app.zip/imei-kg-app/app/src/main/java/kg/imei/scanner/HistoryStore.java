package kg.imei.scanner;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Хранилище истории проверок (SharedPreferences, JSON) + сериализация для экспорта/импорта. */
public final class HistoryStore {

    public static final int STATUS_UNKNOWN = -1;
    public static final int STATUS_NOT_REGISTERED = 0;
    public static final int STATUS_REGISTERED = 1;

    private static final String PREFS = "history";
    private static final String KEY = "items";
    private static final int MAX_ITEMS = 2000;

    public static class Entry {
        public String imei;
        public int status;
        public long time;   // точное время проверки, мс с 1970 года
        public String text; // фрагмент ответа сайта
        public String brand = ""; // производитель устройства ("" — не определён)
    }

    private HistoryStore() {
    }

    // ---------- хранилище ----------

    public static synchronized List<Entry> load(Context c) {
        List<Entry> list = new ArrayList<>();
        try {
            list = parseArray(new JSONArray(prefs(c).getString(KEY, "[]")));
        } catch (Exception ignored) {
        }
        return list;
    }

    public static synchronized void add(Context c, Entry entry) {
        List<Entry> list = load(c);
        list.add(0, entry);
        trim(list);
        save(c, list);
    }

    /** Обновляет запись (поиск по IMEI + времени): производитель, результат, текст. */
    public static synchronized void update(Context c, Entry entry) {
        List<Entry> list = load(c);
        for (Entry e : list) {
            if (e.time == entry.time && e.imei.equals(entry.imei)) {
                e.brand = entry.brand;
                e.status = entry.status;
                e.text = entry.text;
                break;
            }
        }
        save(c, list);
    }

    public static synchronized void remove(Context c, Entry entry) {
        List<Entry> list = load(c);
        for (int i = 0; i < list.size(); i++) {
            Entry e = list.get(i);
            if (e.time == entry.time && e.imei.equals(entry.imei)) {
                list.remove(i);
                break;
            }
        }
        save(c, list);
    }

    public static synchronized void clear(Context c) {
        prefs(c).edit().remove(KEY).apply();
    }

    /** Добавляет записи из импорта, пропуская дубликаты (IMEI + время). Возвращает число добавленных. */
    public static synchronized int merge(Context c, List<Entry> incoming) {
        List<Entry> list = load(c);
        Set<String> keys = new HashSet<>();
        for (Entry e : list) keys.add(key(e));

        int added = 0;
        for (Entry e : incoming) {
            if (keys.add(key(e))) {
                list.add(e);
                added++;
            }
        }
        Collections.sort(list, (a, b) -> Long.compare(b.time, a.time)); // новые сверху
        trim(list);
        save(c, list);
        return added;
    }

    // ---------- экспорт / импорт ----------

    /** JSON для экспорта (его же принимает импорт). */
    public static String toJson(List<Entry> list) {
        try {
            SimpleDateFormat human = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", new Locale("ru", "RU"));
            JSONArray arr = new JSONArray();
            for (Entry e : list) {
                JSONObject o = entryToJson(e);
                o.put("date", human.format(new Date(e.time))); // для удобства чтения, при импорте не используется
                arr.put(o);
            }
            JSONObject root = new JSONObject();
            root.put("app", "imei.kg scanner");
            root.put("version", 1);
            root.put("exported", System.currentTimeMillis());
            root.put("items", arr);
            return root.toString(2);
        } catch (Exception e) {
            return "{}";
        }
    }

    /** Разбирает JSON экспорта (объект с "items" или просто массив). Бросает исключение при неверном формате. */
    public static List<Entry> fromJson(String json) throws Exception {
        String s = json == null ? "" : json.trim();
        if (s.startsWith("﻿")) s = s.substring(1).trim();
        JSONArray arr;
        if (s.startsWith("[")) {
            arr = new JSONArray(s);
        } else {
            arr = new JSONObject(s).getJSONArray("items");
        }
        return parseArray(arr);
    }

    // ---------- внутреннее ----------

    private static List<Entry> parseArray(JSONArray arr) throws Exception {
        List<Entry> list = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            Entry e = new Entry();
            e.imei = o.optString("imei").trim();
            e.time = o.optLong("time");
            if (e.imei.isEmpty() || e.time <= 0) continue; // некорректная запись
            int st = o.optInt("status", STATUS_UNKNOWN);
            e.status = st > 0 ? STATUS_REGISTERED : (st == 0 ? STATUS_NOT_REGISTERED : STATUS_UNKNOWN);
            e.text = o.optString("text");
            e.brand = o.optString("brand");
            list.add(e);
        }
        return list;
    }

    private static JSONObject entryToJson(Entry e) throws Exception {
        JSONObject o = new JSONObject();
        o.put("imei", e.imei);
        o.put("status", e.status);
        o.put("time", e.time);
        o.put("text", e.text == null ? "" : e.text);
        o.put("brand", e.brand == null ? "" : e.brand);
        return o;
    }

    private static String key(Entry e) {
        return e.imei + "|" + e.time;
    }

    private static void trim(List<Entry> list) {
        while (list.size() > MAX_ITEMS) list.remove(list.size() - 1);
    }

    private static void save(Context c, List<Entry> list) {
        try {
            JSONArray arr = new JSONArray();
            for (Entry e : list) arr.put(entryToJson(e));
            prefs(c).edit().putString(KEY, arr.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
