package kg.imei.scanner;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * Заставка при запуске, пока загружается сайт: синий градиент, штрихкод, который «вырастает» по полоскам,
 * красная линия сканера, пульсирующая рамка видоискателя, название и полоска реального прогресса загрузки.
 * Когда страница готова — плавно растворяется.
 */
public class LoadingView extends View {

    private static final long MIN_SHOW_MS = 1600;  // чтобы анимация не мигнула на быстрой загрузке
    private static final long FADE_MS = 500;

    // Ширины штрихов штрихкода: чётные позиции — полоска, нечётные — промежуток
    private static final float[] PATTERN = {2, 1, 1, 2, 3, 1, 1, 1, 2, 2, 1, 3, 1, 2, 2, 1, 3, 1, 1, 2, 1, 1, 3, 2, 1, 2};

    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint framePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint scanPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint titlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final float d;
    private final long startTime = SystemClock.uptimeMillis();

    private Shader gradient;
    private ValueAnimator ticker;
    private float targetProgress = 0.08f;
    private float shownProgress = 0f;
    private boolean dismissScheduled = false;
    private boolean dismissing = false;
    private boolean finished = false;
    private long fadeStart;
    private Runnable onDismissed;

    public LoadingView(Context context) {
        super(context);
        d = context.getResources().getDisplayMetrics().density;
        setClickable(true); // пока заставка видна — не пропускаем нажатия к кнопкам под ней

        glowPaint.setStyle(Paint.Style.FILL);
        barPaint.setStyle(Paint.Style.FILL);

        framePaint.setStyle(Paint.Style.STROKE);
        framePaint.setStrokeWidth(4 * d);
        framePaint.setStrokeCap(Paint.Cap.ROUND);

        scanPaint.setStyle(Paint.Style.STROKE);
        scanPaint.setStrokeCap(Paint.Cap.ROUND);

        titlePaint.setTextAlign(Paint.Align.CENTER);
        titlePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        titlePaint.setLetterSpacing(0.14f);
        titlePaint.setTextSize(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_SP, 30, context.getResources().getDisplayMetrics()));

        trackPaint.setStyle(Paint.Style.FILL);
        fillPaint.setStyle(Paint.Style.FILL);
    }

    /** Вызывается, когда заставка полностью исчезла. */
    public void setOnDismissed(Runnable r) {
        onDismissed = r;
    }

    /** Реальный прогресс загрузки страницы, 0..100. Полоска идёт только вперёд. */
    public void setProgress(int percent) {
        float p = Math.max(0.08f, Math.min(1f, percent / 100f));
        if (p > targetProgress) targetProgress = p;
    }

    /** Страница загрузилась: дождаться минимального времени показа и плавно убрать заставку. */
    public void dismiss() {
        if (dismissScheduled) return;
        dismissScheduled = true;
        targetProgress = 1f;
        long wait = Math.max(0, MIN_SHOW_MS - (SystemClock.uptimeMillis() - startTime));
        postDelayed(() -> {
            dismissing = true;
            fadeStart = SystemClock.uptimeMillis();
        }, wait);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (finished) return;
        ticker = ValueAnimator.ofFloat(0f, 1f);
        ticker.setDuration(1000);
        ticker.setRepeatCount(ValueAnimator.INFINITE);
        ticker.setInterpolator(new LinearInterpolator());
        ticker.addUpdateListener(a -> invalidate()); // перерисовка каждый кадр
        ticker.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (ticker != null) ticker.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        gradient = new LinearGradient(0, 0, 0, h,
                new int[]{0xFF0D47A1, 0xFF1565C0, 0xFF1E88E5},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (finished) return;

        long now = SystemClock.uptimeMillis();
        float t = (now - startTime) / 1000f; // секунды с начала показа
        int w = getWidth();
        int h = getHeight();
        float cx = w / 2f;
        float cy = h / 2f - 40 * d;

        // растворение в конце
        float alpha = 1f;
        float contentScale = 1f;
        if (dismissing) {
            float f = clamp((now - fadeStart) / (float) FADE_MS);
            alpha = 1f - f;
            contentScale = 1f + 0.12f * f * f;
            if (f >= 1f) {
                finished = true;
                post(this::finishHide);
                return;
            }
        }

        // фон
        bgPaint.setShader(gradient);
        bgPaint.setAlpha(Math.round(255 * alpha));
        canvas.drawRect(0, 0, w, h, bgPaint);

        // плавное приближение полоски к реальному прогрессу
        shownProgress += (targetProgress - shownProgress) * 0.10f;

        canvas.save();
        canvas.scale(contentScale, contentScale, w / 2f, h / 2f);

        float pulse = 0.5f + 0.5f * (float) Math.sin(t * 2.6f);
        float pulse2 = 0.5f + 0.5f * (float) Math.sin(t * 1.7f + 1.2f);

        // мягкое светящееся пятно за штрихкодом
        glowPaint.setColor(withAlpha(Color.WHITE, (0.06f + 0.04f * pulse2) * alpha));
        canvas.drawCircle(cx, cy, (118 + 16 * pulse2) * d, glowPaint);

        // штрихкод: полоски по очереди вырастают из центра
        float areaW = 150 * d;
        float areaH = 88 * d;
        float left = cx - areaW / 2f;
        float top = cy - areaH / 2f;
        float sum = 0;
        for (float p : PATTERN) sum += p;
        float unit = areaW / sum;
        float x = left;
        int barIndex = 0;
        barPaint.setColor(withAlpha(Color.WHITE, 0.93f * alpha));
        for (int i = 0; i < PATTERN.length; i++) {
            float bw = PATTERN[i] * unit;
            if (i % 2 == 0) {
                float g = easeOut(clamp((t - 0.05f * barIndex) / 0.5f));
                float hh = areaH * g;
                rect.set(x, cy - hh / 2f, x + bw, cy + hh / 2f);
                canvas.drawRoundRect(rect, 1.5f * d, 1.5f * d, barPaint);
                barIndex++;
            }
            x += bw;
        }

        // красная линия сканера бегает вверх-вниз
        float scanA = clamp((t - 0.5f) / 0.4f) * alpha;
        if (scanA > 0f) {
            float s = 0.5f + 0.5f * (float) Math.sin(t * 3.4f - Math.PI / 2);
            float sy = top + s * areaH;
            scanPaint.setStrokeWidth(14 * d);
            scanPaint.setColor(withAlpha(0xFFFF5252, 0.22f * scanA));
            canvas.drawLine(left - 14 * d, sy, left + areaW + 14 * d, sy, scanPaint);
            scanPaint.setStrokeWidth(3.5f * d);
            scanPaint.setColor(withAlpha(0xFFFF5252, scanA));
            canvas.drawLine(left - 14 * d, sy, left + areaW + 14 * d, sy, scanPaint);
        }

        // рамка видоискателя: уголки «дышат»
        float m = (20 + 4 * pulse) * d;
        float arm = 24 * d;
        framePaint.setColor(withAlpha(Color.WHITE, (0.65f + 0.3f * pulse) * alpha));
        corner(canvas, left - m, top - m, 1, 1, arm);
        corner(canvas, left + areaW + m, top - m, -1, 1, arm);
        corner(canvas, left - m, top + areaH + m, 1, -1, arm);
        corner(canvas, left + areaW + m, top + areaH + m, -1, -1, arm);

        // название
        float ta = easeOut(clamp((t - 0.5f) / 0.6f));
        titlePaint.setColor(withAlpha(Color.WHITE, ta * alpha));
        float ty = cy + areaH / 2f + 82 * d;
        canvas.drawText("IMEI.KG", cx, ty + (1f - ta) * 12 * d, titlePaint);

        // полоска прогресса + бегущий блик (чтобы «жила», даже если загрузка на паузе)
        float trackW = 150 * d;
        float trackH = 5 * d;
        float tl = cx - trackW / 2f;
        float tt = ty + 30 * d;
        rect.set(tl, tt, tl + trackW, tt + trackH);
        trackPaint.setColor(withAlpha(Color.WHITE, 0.25f * ta * alpha));
        canvas.drawRoundRect(rect, trackH / 2f, trackH / 2f, trackPaint);

        fillPaint.setColor(withAlpha(Color.WHITE, 0.95f * ta * alpha));
        rect.set(tl, tt, tl + trackW * Math.max(0.05f, shownProgress), tt + trackH);
        canvas.drawRoundRect(rect, trackH / 2f, trackH / 2f, fillPaint);

        canvas.save();
        canvas.clipRect(tl, tt - 1, tl + trackW, tt + trackH + 1);
        float sweep = ((t * 0.9f) % 1f) * (trackW + 60 * d) - 40 * d;
        rect.set(tl + sweep, tt, tl + sweep + 40 * d, tt + trackH);
        fillPaint.setColor(withAlpha(Color.WHITE, 0.55f * ta * alpha));
        canvas.drawRoundRect(rect, trackH / 2f, trackH / 2f, fillPaint);
        canvas.restore();

        canvas.restore();
    }

    private void finishHide() {
        if (ticker != null) ticker.cancel();
        setVisibility(GONE);
        if (onDismissed != null) onDismissed.run();
    }

    /** Уголок рамки: две линии из точки (x, y) в направлениях dx, dy (±1). */
    private void corner(Canvas c, float x, float y, int dx, int dy, float arm) {
        c.drawLine(x, y, x + dx * arm, y, framePaint);
        c.drawLine(x, y, x, y + dy * arm, framePaint);
    }

    private static float clamp(float v) {
        return Math.max(0f, Math.min(1f, v));
    }

    private static float easeOut(float v) {
        float inv = 1f - v;
        return 1f - inv * inv * inv;
    }

    private static int withAlpha(int color, float a) {
        a = clamp(a);
        return Color.argb(Math.round(Color.alpha(color) * a),
                Color.red(color), Color.green(color), Color.blue(color));
    }
}
