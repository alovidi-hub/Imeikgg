package kg.imei.scanner;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    public static final String EXTRA_RECHECK_IMEI = "recheck_imei";

    private static final String HOME_URL = "https://imei.kg";
    private static final String HOST = "imei.kg";
    private static final int MAX_FILL_ATTEMPTS = 15;    // 15 * 400 мс = 6 секунд ожидания поля ввода
    private static final int MAX_POLL_ATTEMPTS = 24;    // 24 * 500 мс = 12 секунд ожидания результата

    // Признаки результата в тексте, появившемся на странице после нажатия «Проверить».
    // Работают для языков сайта: русский, кыргызский, английский.
    // Сначала проверяется отрицательный вариант (он содержит корень положительного: «не зарегистрирован»).
    private static final Pattern NEGATIVE = Pattern.compile(
            // русский
            "не\\s*зарегистр|незарегистр|не\\s*найден|не\\s*внесен|не\\s*легализ|отсутств|не\\s*оформлен"
                    // кыргызский
                    + "|катталган\\s*эмес|каттала\\s*элек|каттоодон\\s*өтпө|каттоодон\\s*өтө\\s*элек"
                    + "|табылган\\s*жок|табылбады|табыла\\s*элек|жок\\s*экен"
                    // английский
                    + "|not\\s*registered|unregistered|not\\s*found|no\\s*record|not\\s*in\\s*(the\\s*)?(database|registry)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern POSITIVE = Pattern.compile(
            // русский
            "зарегистр|найден|внесен|легализ|оформлен"
                    // кыргызский
                    + "|катталган|каттоодон\\s*өткөн|табылды|табылган|легалдаш"
                    // английский
                    + "|registered|found|legali[sz]ed",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    // Возвращает только новые строки, появившиеся на странице после снимка (window.__imeiBefore)
    private static final String JS_DIFF = "(function(){var s={};var b=window.__imeiBefore;"
            // если страница перезагрузилась после нажатия «Проверить», снимок берём из sessionStorage
            + "if(!b){try{b=JSON.parse(sessionStorage.getItem('imeiBefore')||'[]');}catch(e){b=[];}}"
            + "b.forEach(function(x){s[x]=1;});"
            + "var cur=(document.body.innerText||'').split('\\n').map(function(x){return x.trim();}).filter(Boolean);"
            + "return cur.filter(function(x){return !s[x];}).join('\\n').substring(0,1500);})()";

    // Перехват РУЧНОЙ проверки: когда пользователь сам ввёл IMEI и нажал «Проверить» (клик, отправка формы
    // или Enter), страница запоминает свой текст «до» и сообщает приложению через AndroidBridge.
    private static final String JS_HOOK = "(function(){"
            + "if(window.__imeiHooked)return;window.__imeiHooked=true;"
            // текст кнопки проверки: русский / кыргызский / английский
            + "var RE=/проверить|проверка|проверь|найти|поиск|отправить|текшер|издөө|издоо|жиберүү|табуу|check|verify|search|find|submit/i;"
            + "var IMEI=/imei|имеи|имей/i;"
            + "function ok(e){var t=(e.type||'text').toLowerCase();"
            + "return ['text','tel','number','search',''].indexOf(t)>=0&&!e.disabled&&e.offsetParent!==null;}"
            + "function pick(scope){var l=[].slice.call(scope.querySelectorAll('input,textarea')).filter(ok);"
            + "return l.filter(function(e){return IMEI.test((e.name||'')+(e.id||'')+(e.placeholder||'')+(e.className||''));})[0]||l[0];}"
            + "function snap(){var lines=(document.body.innerText||'').split('\\n').map(function(x){return x.trim();}).filter(Boolean);"
            + "window.__imeiBefore=lines;try{sessionStorage.setItem('imeiBefore',JSON.stringify(lines));}catch(e){}}"
            + "function report(src){if(window.__imeiSuppress)return;"
            + "var form=src&&src.closest?src.closest('form'):null;"
            + "var el=(form&&pick(form))||pick(document);if(!el)return;"
            + "var v=String(el.value||'').trim();if(!v)return;"
            + "var now=Date.now();var last=window.__imeiLast||{};"
            + "if(last.v===v&&now-last.t<1500)return;window.__imeiLast={v:v,t:now};"
            + "snap();try{AndroidBridge.onManualCheck(v);}catch(e){}}"
            + "document.addEventListener('click',function(ev){"
            + "var t=ev.target&&ev.target.closest?ev.target.closest('button,input[type=submit],input[type=button],a,[role=button]'):null;"
            + "if(!t)return;"
            // ссылки, ведущие на другую страницу (меню), не считаем кнопкой проверки
            + "if(t.tagName==='A'){var h=t.getAttribute('href')||'';if(h&&h.charAt(0)!=='#'&&h.indexOf('javascript')!==0)return;}"
            + "var txt=String(t.innerText||t.value||t.textContent||'');"
            + "var sub=(t.tagName==='BUTTON'&&(t.type||'submit')==='submit')||(t.tagName==='INPUT'&&t.type==='submit');"
            + "if(RE.test(txt)||sub)report(t);},true);"
            + "document.addEventListener('submit',function(ev){report(ev.target);},true);"
            + "document.addEventListener('keydown',function(ev){"
            + "if(ev.key==='Enter'&&ev.target&&ev.target.tagName==='INPUT')report(ev.target);},true);"
            + "})()";

    private WebView webView;
    private ProgressBar progressBar;
    private ResultAnimationView resultView;
    private LoadingView loadingView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    /** Адрес главной страницы в текущем языке сайта (обновляется по мере навигации). */
    private String homeUrl = HOME_URL;

    /** Номер текущей проверки: устаревшие отложенные действия предыдущих проверок отбрасываются. */
    private int currentCheckId = 0;
    /** IMEI, который нужно вставить и проверить, как только страница загрузится. */
    private String pendingImei = null;
    private int pendingCheckId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);

        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        FrameLayout.LayoutParams pbParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(4));
        pbParams.gravity = Gravity.TOP;
        root.addView(progressBar, pbParams);

        // Кнопка «Сканировать IMEI» — справа внизу
        Button scanButton = makeButton("📷  Сканировать IMEI", Color.parseColor("#1565C0"), Color.WHITE);
        FrameLayout.LayoutParams scanParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, dp(56));
        scanParams.gravity = Gravity.BOTTOM | Gravity.END;
        scanParams.setMargins(dp(16), dp(16), dp(16), dp(24));
        root.addView(scanButton, scanParams);
        scanButton.setOnClickListener(v -> startScan());

        // Кнопка «История» — слева внизу
        Button historyButton = makeButton("🕘  История", Color.WHITE, Color.parseColor("#1565C0"));
        FrameLayout.LayoutParams histParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, dp(56));
        histParams.gravity = Gravity.BOTTOM | Gravity.START;
        histParams.setMargins(dp(16), dp(16), dp(16), dp(24));
        root.addView(historyButton, histParams);
        historyButton.setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));

        // Анимация результата — поверх всего
        resultView = new ResultAnimationView(this);
        root.addView(resultView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        // Заставка загрузки — самый верхний слой; статус-бар на это время в цвет заставки
        final int oldStatusColor = getWindow().getStatusBarColor();
        getWindow().setStatusBarColor(0xFF0D47A1);
        loadingView = new LoadingView(this);
        loadingView.setOnDismissed(() -> getWindow().setStatusBarColor(oldStatusColor));
        root.addView(loadingView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        // на случай, если сайт не отвечает: не держим заставку дольше 15 секунд
        handler.postDelayed(() -> loadingView.dismiss(), 15000);

        setContentView(root);

        setupWebView();

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            loadHome();
            handleRecheckIntent(getIntent());
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleRecheckIntent(intent);
    }

    /** «Проверить снова» из истории. */
    private void handleRecheckIntent(Intent intent) {
        if (intent == null) return;
        String imei = intent.getStringExtra(EXTRA_RECHECK_IMEI);
        if (imei != null && !imei.isEmpty()) {
            intent.removeExtra(EXTRA_RECHECK_IMEI);
            startCheck(imei);
        }
    }

    private Button makeButton(String text, int bgColor, int textColor) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(textColor);
        b.setTextSize(16);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(bgColor);
        bg.setCornerRadius(dp(28));
        bg.setStroke(dp(2), Color.parseColor("#1565C0"));
        b.setBackground(bg);
        b.setPadding(dp(22), dp(12), dp(22), dp(12));
        b.setElevation(dp(6));
        return b;
    }

    /**
     * Загружает главную страницу сайта на том языке, который сейчас выбран пользователем на сайте.
     * Язык приложение не переключает: если он зашит в адрес (imei.kg/ky, ?lang=en), адрес сохраняется.
     */
    private void loadHome() {
        webView.loadUrl(homeUrl);
    }

    /** Запоминает «главную» в текущем языке сайта по адресу открытой страницы. */
    private void updateHomeUrl(String url) {
        if (url == null) return;
        try {
            Uri u = Uri.parse(url);
            String host = u.getHost();
            if (host == null || !(host.equals(HOST) || host.endsWith("." + HOST))) return;

            StringBuilder sb = new StringBuilder(u.getScheme()).append("://").append(host);
            java.util.List<String> segs = u.getPathSegments();
            if (!segs.isEmpty() && segs.get(0).matches("(?i)ru|ky|kg|en|kk|uz")) {
                sb.append('/').append(segs.get(0));
            }
            for (String key : new String[]{"lang", "language", "locale", "hl"}) {
                String val = u.getQueryParameter(key);
                if (val != null && !val.isEmpty()) {
                    sb.append("?").append(key).append("=").append(Uri.encode(val));
                    break;
                }
            }
            homeUrl = sb.toString();
        } catch (Exception ignored) {
        }
    }

    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new JsBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && (host.equals(HOST) || host.endsWith("." + HOST))) {
                    return false; // остаёмся внутри приложения
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                // нет сети / сайт недоступен: убираем заставку, чтобы было видно сообщение об ошибке
                if (request != null && request.isForMainFrame()) loadingView.dismiss();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                loadingView.dismiss(); // страница готова — заставка плавно исчезает

                updateHomeUrl(url);

                // следим за ручными проверками на каждой загруженной странице
                view.evaluateJavascript(JS_HOOK, null);

                if (pendingImei != null) {
                    // страница перезагружена после сканирования — вставляем IMEI и запускаем проверку
                    String imei = pendingImei;
                    int id = pendingCheckId;
                    pendingImei = null;
                    fillImei(imei, 0, id);
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                loadingView.setProgress(newProgress);
                progressBar.setVisibility(newProgress < 100 ? View.VISIBLE : View.GONE);
            }
        });
    }

    // ---------- Сканер ----------

    private void startScan() {
        GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(
                        Barcode.FORMAT_CODE_128,
                        Barcode.FORMAT_CODE_39,
                        Barcode.FORMAT_CODE_93,
                        Barcode.FORMAT_EAN_13,
                        Barcode.FORMAT_EAN_8,
                        Barcode.FORMAT_ITF,
                        Barcode.FORMAT_UPC_A,
                        Barcode.FORMAT_QR_CODE,
                        Barcode.FORMAT_DATA_MATRIX,
                        Barcode.FORMAT_PDF417)
                .enableAutoZoom()
                .build();

        GmsBarcodeScanner scanner = GmsBarcodeScanning.getClient(this, options);
        scanner.startScan()
                .addOnSuccessListener(barcode -> onScanned(barcode.getRawValue()))
                .addOnCanceledListener(() -> { /* пользователь закрыл сканер */ })
                .addOnFailureListener(e -> Toast.makeText(this,
                        "Не удалось открыть сканер: " + e.getMessage()
                                + "\nПроверьте, что установлены Google Play services.",
                        Toast.LENGTH_LONG).show());
    }

    private void onScanned(String raw) {
        if (raw == null || raw.isEmpty()) {
            Toast.makeText(this, "Код не распознан", Toast.LENGTH_SHORT).show();
            return;
        }
        startCheck(extractImei(raw));
    }

    /** Каждая новая проверка начинается заново: перезагрузка страницы → вставка IMEI → «Проверить». */
    private void startCheck(String imei) {
        currentCheckId++;
        pendingImei = imei;
        pendingCheckId = currentCheckId;
        Toast.makeText(this, "IMEI: " + imei + " — проверяем…", Toast.LENGTH_SHORT).show();
        loadHome();
    }

    /** Достаёт IMEI из значения штрихкода/QR. */
    private String extractImei(String raw) {
        // 1) ровно 15 цифр подряд (стандартный IMEI)
        Matcher m = Pattern.compile("(?<!\\d)\\d{15}(?!\\d)").matcher(raw);
        if (m.find()) return m.group();
        // 2) только цифры, если длина похожа на IMEI/IMEISV
        String digits = raw.replaceAll("\\D", "");
        if (digits.length() >= 14 && digits.length() <= 16) return digits;
        // 3) как есть
        return raw.trim();
    }

    /** Вставляет значение в поле ввода IMEI и нажимает «Проверить». Ждёт появления поля до 6 секунд. */
    private void fillImei(String imei, int attempt, int id) {
        if (id != currentCheckId) return;

        String js = "(function(v){"
                + "var list=[].slice.call(document.querySelectorAll('input,textarea')).filter(function(e){"
                + "var t=(e.type||'text').toLowerCase();"
                + "return ['text','tel','number','search',''].indexOf(t)>=0&&!e.disabled&&!e.readOnly&&e.offsetParent!==null;});"
                + "var el=list.filter(function(e){return /imei|имеи|имей/i.test((e.name||'')+(e.id||'')+(e.placeholder||'')+(e.className||''));})[0]||list[0];"
                + "if(!el)return 'no_input';"
                + "el.focus();"
                + "var proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;"
                + "Object.getOwnPropertyDescriptor(proto,'value').set.call(el,v);"
                + "el.dispatchEvent(new Event('input',{bubbles:true}));"
                + "el.dispatchEvent(new Event('change',{bubbles:true}));"
                // снимок текста страницы ДО проверки — чтобы потом выделить только новый ответ сайта
                + "window.__imeiBefore=(document.body.innerText||'').split('\\n').map(function(x){return x.trim();}).filter(Boolean);"
                + "try{sessionStorage.setItem('imeiBefore',JSON.stringify(window.__imeiBefore));}catch(e){}"
                // нажать «Проверить» через 0.3 с, чтобы сайт успел принять значение
                + "setTimeout(function(){"
                // наш собственный клик не должен восприниматься как ручная проверка
                + "window.__imeiSuppress=true;"
                + "var f=function(r,s){return [].slice.call(r.querySelectorAll(s)).filter(function(b){"
                + "var t=String(b.innerText||b.value||b.textContent||'').toLowerCase();"
                // текст кнопки проверки: русский / кыргызский / английский
                + "return /проверить|проверка|проверь|найти|поиск|отправить|текшер|издөө|издоо|жиберүү|табуу|check|verify|search|find|submit/.test(t)&&b.offsetParent!==null;})[0];};"
                + "var S='button,input[type=submit],input[type=button],[role=button]';"
                + "var btn=(el.form&&f(el.form,S))||f(document,S)||f(document,'a');"
                + "if(!btn&&el.form)btn=el.form.querySelector('button[type=submit],input[type=submit]');"
                + "if(btn){btn.click();}"
                + "else if(el.form){if(el.form.requestSubmit)el.form.requestSubmit();else el.form.submit();}"
                + "else{['keydown','keypress','keyup'].forEach(function(n){el.dispatchEvent(new KeyboardEvent(n,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));});}"
                + "setTimeout(function(){window.__imeiSuppress=false;},600);"
                + "},300);"
                + "return 'ok';"
                + "})(" + JSONObject.quote(imei) + ")";

        webView.evaluateJavascript(js, result -> {
            if (id != currentCheckId) return;
            if (result != null && result.contains("ok")) {
                // проверка запущена — ждём ответ сайта
                handler.postDelayed(() -> pollResult(imei, 0, id), 700);
                return;
            }
            if (attempt < MAX_FILL_ATTEMPTS) {
                // страница ещё рисуется — пробуем снова
                handler.postDelayed(() -> fillImei(imei, attempt + 1, id), 400);
            } else {
                // Поле не найдено — копируем в буфер обмена
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("IMEI", imei));
                Toast.makeText(this,
                        "Поле ввода не найдено. IMEI " + imei + " скопирован в буфер обмена.",
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    // ---------- Ручная проверка (пользователь сам ввёл IMEI и нажал «Проверить») ----------

    /** Мост JavaScript → приложение. Вызывается из JS_HOOK в потоке WebView, поэтому переходим в UI-поток. */
    private class JsBridge {
        @JavascriptInterface
        public void onManualCheck(String value) {
            runOnUiThread(() -> startManualCheck(value));
        }
    }

    private void startManualCheck(String value) {
        if (value == null) return;
        String digits = value.replaceAll("\\D", "");
        if (digits.length() < 14 || digits.length() > 16) return; // неполный/некорректный ввод — не отслеживаем

        String imei = extractImei(value);
        currentCheckId++;          // отменяет ожидания предыдущей проверки
        pendingImei = null;        // перезагрузка страницы не нужна — сайт уже обрабатывает запрос
        int id = currentCheckId;
        handler.postDelayed(() -> pollResult(imei, 0, id), 500);
    }

    // ---------- Результат проверки ----------

    /** Каждые 0,5 с смотрит, какой новый текст появился на странице, и определяет результат. */
    private void pollResult(String imei, int attempt, int id) {
        if (id != currentCheckId) return;

        webView.evaluateJavascript(JS_DIFF, raw -> {
            if (id != currentCheckId) return;
            String text = unquote(raw);
            int status = classify(text);

            if (status != HistoryStore.STATUS_UNKNOWN) {
                finishCheck(imei, status, text);
            } else if (attempt < MAX_POLL_ATTEMPTS) {
                handler.postDelayed(() -> pollResult(imei, attempt + 1, id), 500);
            } else {
                finishCheck(imei, HistoryStore.STATUS_UNKNOWN, text);
            }
        });
    }

    private int classify(String text) {
        if (text == null || text.isEmpty()) return HistoryStore.STATUS_UNKNOWN;
        if (NEGATIVE.matcher(text).find()) return HistoryStore.STATUS_NOT_REGISTERED;
        if (POSITIVE.matcher(text).find()) return HistoryStore.STATUS_REGISTERED;
        return HistoryStore.STATUS_UNKNOWN;
    }

    private void finishCheck(String imei, int status, String text) {
        // сохраняем в историю с точным временем
        HistoryStore.Entry e = new HistoryStore.Entry();
        e.imei = imei;
        e.status = status;
        e.time = System.currentTimeMillis();
        String note = text == null ? "" : text.replace('\n', ' ').trim();
        e.text = note.length() > 200 ? note.substring(0, 200) + "…" : note;
        e.brand = Brands.detect(text); // производитель из ответа сайта ("" если не найден)
        HistoryStore.add(this, e);

        if (status == HistoryStore.STATUS_UNKNOWN) {
            Toast.makeText(this,
                    "Результат не распознан. Запись сохранена в историю.", Toast.LENGTH_LONG).show();
            return;
        }

        // подпись под анимацией — на языке, на котором сайт показал результат (ru / ky / en)
        final boolean registered = status == HistoryStore.STATUS_REGISTERED;
        webView.evaluateJavascript("(document.documentElement.lang||'')", raw -> {
            String lang = detectLang(unquote(raw), text);
            resultView.play(registered, resultLabel(lang, registered));
        });
    }

    /** Язык ответа сайта: по специфичным кыргызским буквам, затем по атрибуту lang, затем по алфавиту текста. */
    private String detectLang(String langAttr, String text) {
        String a = langAttr == null ? "" : langAttr.toLowerCase(Locale.ROOT);
        if (text != null && text.matches("(?s).*[үөңҮӨҢ].*")) return "ky";
        if (a.startsWith("ky") || a.startsWith("kg")) return "ky";
        if (a.startsWith("en")) return "en";
        if (a.startsWith("ru")) return "ru";
        if (text != null && !text.matches("(?s).*[\\u0400-\\u04FF].*") && text.matches("(?s).*[A-Za-z].*")) {
            return "en";
        }
        return "ru";
    }

    private String resultLabel(String lang, boolean registered) {
        switch (lang) {
            case "ky":
                return registered ? "Катталган" : "Катталган эмес";
            case "en":
                return registered ? "Registered" : "Not registered";
            default:
                return registered ? "Зарегистрирован" : "Не зарегистрирован";
        }
    }

    /** Результат evaluateJavascript приходит как JSON-строка в кавычках — раскодируем её. */
    private String unquote(String raw) {
        if (raw == null || raw.equals("null")) return "";
        try {
            return new JSONArray("[" + raw + "]").getString(0);
        } catch (Exception e) {
            return "";
        }
    }

    // ---------- Навигация ----------

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
