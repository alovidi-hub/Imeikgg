package kg.imei.scanner;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    public static final String EXTRA_RECHECK_IMEI = "recheck_imei";

    private static final String HOME_URL = "https://imei.kg";
    private static final String HOST = "imei.kg";
    private static final int MAX_FILL_ATTEMPTS = 15;    // 15 * 400 мс = 6 секунд ожидания поля ввода
    private static final int MAX_POLL_ATTEMPTS = 24;    // 24 * 500 мс = 12 секунд ожидания результата

    // Признаки результата в тексте, появившемся на странице после нажатия «Проверить».
    // Сначала проверяется отрицательный вариант (он содержит слово «зарегистрирован»).
    private static final Pattern NEGATIVE = Pattern.compile(
            "не\\s*зарегистр|незарегистр|не\\s*найден|не\\s*внесен|не\\s*легализ|отсутств|не\\s*оформлен"
                    + "|not\\s*registered|not\\s*found",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern POSITIVE = Pattern.compile(
            "зарегистр|найден|внесен|легализ|оформлен|registered|found",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    // Возвращает только новые строки, появившиеся на странице после снимка (window.__imeiBefore)
    private static final String JS_DIFF = "(function(){var s={};"
            + "(window.__imeiBefore||[]).forEach(function(x){s[x]=1;});"
            + "var cur=(document.body.innerText||'').split('\\n').map(function(x){return x.trim();}).filter(Boolean);"
            + "return cur.filter(function(x){return !s[x];}).join('\\n').substring(0,1500);})()";

    private WebView webView;
    private ProgressBar progressBar;
    private ResultAnimationView resultView;
    private final Handler handler = new Handler(Looper.getMainLooper());

    /** Номер текущей проверки: устаревшие отложенные действия предыдущих проверок отбрасываются. */
    private int currentCheckId = 0;
    /** IMEI, который нужно вставить и проверить, как только страница загрузится. */
    private String pendingImei = null;
    private int pendingCheckId = 0;
    /** Язык сайта проверяется один раз при запуске приложения. */
    private boolean languageChecked = false;

    // Язык приложения и запросов WebView по умолчанию — русский
    @Override
    protected void attachBaseContext(Context base) {
        Locale ru = new Locale("ru", "RU");
        Locale.setDefault(ru);
        Configuration config = new Configuration(base.getResources().getConfiguration());
        config.setLocale(ru);
        super.attachBaseContext(base.createConfigurationContext(config));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);

        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        FrameLayout.LayoutParams pbParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(4));
        pbParams.gravity = Gravity.TOP;
        root.addView(progressBar, pbParams);

        // Кнопка «Сканировать IMEI» — справа внизу
        Button scanButton = makeButton("📷  Сканировать IMEI", Color.parseColor("#1565C0"), Color.WHITE);
        FrameLayout.LayoutParams scanParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, dp(56));
        scanParams.gravity = Gravity.BOTTOM | Gravity.END;
        scanParams.setMargins(dp(16), dp(16), dp(16), dp(24));
        root.addView(scanButton, scanParams);
        scanButton.setOnClickListener(v -> startScan());

        // Кнопка «История» — слева внизу
        Button historyButton = makeButton("🕘  История", Color.WHITE, Color.parseColor("#1565C0"));
        FrameLayout.LayoutParams histParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, dp(56));
        histParams.gravity = Gravity.BOTTOM | Gravity.START;
        histParams.setMargins(dp(16), dp(16), dp(16), dp(24));
        root.addView(historyButton, histParams);
        historyButton.setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));

        // Анимация результата — поверх всего
        resultView = new ResultAnimationView(this);
        root.addView(resultView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        setContentView(root);

        setupWebView();

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
            languageChecked = true;
        } else {
            loadHome();
            handleRecheckIntent(getIntent());
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleRecheckIntent(intent);
    }

    /** «Проверить снова» из истории. */
    private void handleRecheckIntent(Intent intent) {
        if (intent == null) return;
        String imei = intent.getStringExtra(EXTRA_RECHECK_IMEI);
        if (imei != null && !imei.isEmpty()) {
            intent.removeExtra(EXTRA_RECHECK_IMEI);
            startCheck(imei);
        }
    }

    private Button makeButton(String text, int bgColor, int textColor) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(textColor);
        b.setTextSize(16);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(bgColor);
        bg.setCornerRadius(dp(28));
        bg.setStroke(dp(2), Color.parseColor("#1565C0"));
        b.setBackground(bg);
        b.setPadding(dp(22), dp(12), dp(22), dp(12));
        b.setElevation(dp(6));
        return b;
    }

    /** Загружает главную страницу сайта с русским языком в заголовках запроса. */
    private void loadHome() {
        Map<String, String> headers = new HashMap<>();
        headers.put("Accept-Language", "ru-RU,ru;q=0.9");
        webView.loadUrl(HOME_URL, headers);
    }

    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && (host.equals(HOST) || host.endsWith("." + HOST))) {
                    return false; // остаёмся внутри приложения
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);

                if (pendingImei != null) {
                    // страница перезагружена после сканирования — вставляем IMEI и запускаем проверку
                    String imei = pendingImei;
                    int id = pendingCheckId;
                    pendingImei = null;
                    languageChecked = true;
                    fillImei(imei, 0, id);
                } else if (!languageChecked) {
                    languageChecked = true;
                    ensureRussian();
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress < 100 ? View.VISIBLE : View.GONE);
            }
        });
    }

    // ---------- Русский язык сайта по умолчанию ----------

    /** Если сайт открылся не на русском — нажимаем переключатель «RU / Русский». */
    private void ensureRussian() {
        String js = "(function(){"
                + "var l=(document.documentElement.lang||'').toLowerCase();"
                + "if(l.indexOf('ru')===0)return 'ru';"
                + "var re=/^(ru|rus|рус|русский|russian)$/i;"
                + "var t=[].slice.call(document.querySelectorAll('a,button,li,span,div,option')).filter(function(e){"
                + "return e.children.length===0&&re.test((e.textContent||'').trim());})[0];"
                + "if(!t)return 'none';"
                + "if(t.tagName==='OPTION'){var s=t.parentElement;if(s&&s.tagName==='OPTGROUP')s=s.parentElement;"
                + "if(s){s.value=t.value;s.dispatchEvent(new Event('change',{bubbles:true}));}}"
                + "else{t.click();}"
                + "return 'clicked';"
                + "})()";
        webView.evaluateJavascript(js, null);
    }

    // ---------- Сканер ----------

    private void startScan() {
        GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(
                        Barcode.FORMAT_CODE_128,
                        Barcode.FORMAT_CODE_39,
                        Barcode.FORMAT_CODE_93,
                        Barcode.FORMAT_EAN_13,
                        Barcode.FORMAT_EAN_8,
                        Barcode.FORMAT_ITF,
                        Barcode.FORMAT_UPC_A,
                        Barcode.FORMAT_QR_CODE,
                        Barcode.FORMAT_DATA_MATRIX,
                        Barcode.FORMAT_PDF417)
                .enableAutoZoom()
                .build();

        GmsBarcodeScanner scanner = GmsBarcodeScanning.getClient(this, options);
        scanner.startScan()
                .addOnSuccessListener(barcode -> onScanned(barcode.getRawValue()))
                .addOnCanceledListener(() -> { /* пользователь закрыл сканер */ })
                .addOnFailureListener(e -> Toast.makeText(this,
                        "Не удалось открыть сканер: " + e.getMessage()
                                + "\nПроверьте, что установлены Google Play services.",
                        Toast.LENGTH_LONG).show());
    }

    private void onScanned(String raw) {
        if (raw == null || raw.isEmpty()) {
            Toast.makeText(this, "Код не распознан", Toast.LENGTH_SHORT).show();
            return;
        }
        startCheck(extractImei(raw));
    }

    /** Каждая новая проверка начинается заново: перезагрузка страницы → вставка IMEI → «Проверить». */
    private void startCheck(String imei) {
        currentCheckId++;
        pendingImei = imei;
        pendingCheckId = currentCheckId;
        Toast.makeText(this, "IMEI: " + imei + " — проверяем…", Toast.LENGTH_SHORT).show();
        loadHome();
    }

    /** Достаёт IMEI из значения штрихкода/QR. */
    private String extractImei(String raw) {
        // 1) ровно 15 цифр подряд (стандартный IMEI)
        Matcher m = Pattern.compile("(?<!\\d)\\d{15}(?!\\d)").matcher(raw);
        if (m.find()) return m.group();
        // 2) только цифры, если длина похожа на IMEI/IMEISV
        String digits = raw.replaceAll("\\D", "");
        if (digits.length() >= 14 && digits.length() <= 16) return digits;
        // 3) как есть
        return raw.trim();
    }

    /** Вставляет значение в поле ввода IMEI и нажимает «Проверить». Ждёт появления поля до 6 секунд. */
    private void fillImei(String imei, int attempt, int id) {
        if (id != currentCheckId) return;

        String js = "(function(v){"
                + "var list=[].slice.call(document.querySelectorAll('input,textarea')).filter(function(e){"
                + "var t=(e.type||'text').toLowerCase();"
                + "return ['text','tel','number','search',''].indexOf(t)>=0&&!e.disabled&&!e.readOnly&&e.offsetParent!==null;});"
                + "var el=list.filter(function(e){return /imei/i.test((e.name||'')+(e.id||'')+(e.placeholder||'')+(e.className||''));})[0]||list[0];"
                + "if(!el)return 'no_input';"
                + "el.focus();"
                + "var proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;"
                + "Object.getOwnPropertyDescriptor(proto,'value').set.call(el,v);"
                + "el.dispatchEvent(new Event('input',{bubbles:true}));"
                + "el.dispatchEvent(new Event('change',{bubbles:true}));"
                // снимок текста страницы ДО проверки — чтобы потом выделить только новый ответ сайта
                + "window.__imeiBefore=(document.body.innerText||'').split('\\n').map(function(x){return x.trim();}).filter(Boolean);"
                // нажать «Проверить» через 0.3 с, чтобы сайт успел принять значение
                + "setTimeout(function(){"
                + "var f=function(r,s){return [].slice.call(r.querySelectorAll(s)).filter(function(b){"
                + "var t=String(b.innerText||b.value||b.textContent||'').toLowerCase();"
                + "return /проверить|проверка|проверь|check|найти|поиск|search|отправить|submit/.test(t)&&b.offsetParent!==null;})[0];};"
                + "var S='button,input[type=submit],input[type=button],[role=button]';"
                + "var btn=(el.form&&f(el.form,S))||f(document,S)||f(document,'a');"
                + "if(!btn&&el.form)btn=el.form.querySelector('button[type=submit],input[type=submit]');"
                + "if(btn){btn.click();}"
                + "else if(el.form){if(el.form.requestSubmit)el.form.requestSubmit();else el.form.submit();}"
                + "else{['keydown','keypress','keyup'].forEach(function(n){el.dispatchEvent(new KeyboardEvent(n,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));});}"
                + "},300);"
                + "return 'ok';"
                + "})(" + JSONObject.quote(imei) + ")";

        webView.evaluateJavascript(js, result -> {
            if (id != currentCheckId) return;
            if (result != null && result.contains("ok")) {
                // проверка запущена — ждём ответ сайта
                handler.postDelayed(() -> pollResult(imei, 0, id), 700);
                return;
            }
            if (attempt < MAX_FILL_ATTEMPTS) {
                // страница ещё рисуется — пробуем снова
                handler.postDelayed(() -> fillImei(imei, attempt + 1, id), 400);
            } else {
                // Поле не найдено — копируем в буфер обмена
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("IMEI", imei));
                Toast.makeText(this,
                        "Поле ввода не найдено. IMEI " + imei + " скопирован в буфер обмена.",
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    // ---------- Результат проверки ----------

    /** Каждые 0,5 с смотрит, какой новый текст появился на странице, и определяет результат. */
    private void pollResult(String imei, int attempt, int id) {
        if (id != currentCheckId) return;

        webView.evaluateJavascript(JS_DIFF, raw -> {
            if (id != currentCheckId) return;
            String text = unquote(raw);
            int status = classify(text);

            if (status != HistoryStore.STATUS_UNKNOWN) {
                finishCheck(imei, status, text);
            } else if (attempt < MAX_POLL_ATTEMPTS) {
                handler.postDelayed(() -> pollResult(imei, attempt + 1, id), 500);
            } else {
                finishCheck(imei, HistoryStore.STATUS_UNKNOWN, text);
            }
        });
    }

    private int classify(String text) {
        if (text == null || text.isEmpty()) return HistoryStore.STATUS_UNKNOWN;
        if (NEGATIVE.matcher(text).find()) return HistoryStore.STATUS_NOT_REGISTERED;
        if (POSITIVE.matcher(text).find()) return HistoryStore.STATUS_REGISTERED;
        return HistoryStore.STATUS_UNKNOWN;
    }

    private void finishCheck(String imei, int status, String text) {
        // сохраняем в историю с точным временем
        HistoryStore.Entry e = new HistoryStore.Entry();
        e.imei = imei;
        e.status = status;
        e.time = System.currentTimeMillis();
        String note = text == null ? "" : text.replace('\n', ' ').trim();
        e.text = note.length() > 200 ? note.substring(0, 200) + "…" : note;
        e.brand = Brands.detect(text); // производитель из ответа сайта ("" если не найден)
        HistoryStore.add(this, e);

        if (status == HistoryStore.STATUS_REGISTERED) {
            resultView.play(true, "Зарегистрирован");
        } else if (status == HistoryStore.STATUS_NOT_REGISTERED) {
            resultView.play(false, "Не зарегистрирован");
        } else {
            Toast.makeText(this,
                    "Результат не распознан. Запись сохранена в историю.", Toast.LENGTH_LONG).show();
        }
    }

    /** Результат evaluateJavascript приходит как JSON-строка в кавычках — раскодируем её. */
    private String unquote(String raw) {
        if (raw == null || raw.equals("null")) return "";
        try {
            return new JSONArray("[" + raw + "]").getString(0);
        } catch (Exception e) {
            return "";
        }
    }

    // ---------- Навигация ----------

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
