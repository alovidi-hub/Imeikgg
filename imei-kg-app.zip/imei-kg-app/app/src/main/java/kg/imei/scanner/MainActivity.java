package kg.imei.scanner;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;

import org.json.JSONObject;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String HOME_URL = "https://imei.kg";
    private static final String HOST = "imei.kg";

    private WebView webView;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);

        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        FrameLayout.LayoutParams pbParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(4));
        pbParams.gravity = Gravity.TOP;
        root.addView(progressBar, pbParams);

        Button scanButton = new Button(this);
        scanButton.setText("📷  Сканировать IMEI");
        scanButton.setAllCaps(false);
        scanButton.setTextColor(Color.WHITE);
        scanButton.setTextSize(16);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1565C0"));
        bg.setCornerRadius(dp(28));
        scanButton.setBackground(bg);
        scanButton.setPadding(dp(24), dp(12), dp(24), dp(12));
        scanButton.setElevation(dp(6));
        FrameLayout.LayoutParams btnParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, dp(56));
        btnParams.gravity = Gravity.BOTTOM | Gravity.END;
        btnParams.setMargins(dp(16), dp(16), dp(16), dp(24));
        root.addView(scanButton, btnParams);
        scanButton.setOnClickListener(v -> startScan());

        setContentView(root);

        setupWebView();

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(HOME_URL);
        }
    }

    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && (host.equals(HOST) || host.endsWith("." + HOST))) {
                    return false; // остаёмся внутри приложения
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress < 100 ? View.VISIBLE : View.GONE);
            }
        });
    }

    // ---------- Сканер ----------

    private void startScan() {
        GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(
                        Barcode.FORMAT_CODE_128,
                        Barcode.FORMAT_CODE_39,
                        Barcode.FORMAT_CODE_93,
                        Barcode.FORMAT_EAN_13,
                        Barcode.FORMAT_EAN_8,
                        Barcode.FORMAT_ITF,
                        Barcode.FORMAT_UPC_A,
                        Barcode.FORMAT_QR_CODE,
                        Barcode.FORMAT_DATA_MATRIX,
                        Barcode.FORMAT_PDF417)
                .enableAutoZoom()
                .build();

        GmsBarcodeScanner scanner = GmsBarcodeScanning.getClient(this, options);
        scanner.startScan()
                .addOnSuccessListener(barcode -> onScanned(barcode.getRawValue()))
                .addOnCanceledListener(() -> { /* пользователь закрыл сканер */ })
                .addOnFailureListener(e -> Toast.makeText(this,
                        "Не удалось открыть сканер: " + e.getMessage()
                                + "\nПроверьте, что установлены Google Play services.",
                        Toast.LENGTH_LONG).show());
    }

    private void onScanned(String raw) {
        if (raw == null || raw.isEmpty()) {
            Toast.makeText(this, "Код не распознан", Toast.LENGTH_SHORT).show();
            return;
        }
        String imei = extractImei(raw);
        fillImei(imei);
    }

    /** Достаёт IMEI из значения штрихкода/QR. */
    private String extractImei(String raw) {
        // 1) ровно 15 цифр подряд (стандартный IMEI)
        Matcher m = Pattern.compile("(?<!\\d)\\d{15}(?!\\d)").matcher(raw);
        if (m.find()) return m.group();
        // 2) только цифры, если длина похожа на IMEI/IMEISV
        String digits = raw.replaceAll("\\D", "");
        if (digits.length() >= 14 && digits.length() <= 16) return digits;
        // 3) как есть
        return raw.trim();
    }

    /** Вставляет значение в поле ввода IMEI на странице. */
    private void fillImei(String imei) {
        String js = "(function(v){"
                + "var list=[].slice.call(document.querySelectorAll('input,textarea')).filter(function(e){"
                + "var t=(e.type||'text').toLowerCase();"
                + "return ['text','tel','number','search',''].indexOf(t)>=0&&!e.disabled&&!e.readOnly&&e.offsetParent!==null;});"
                + "var el=list.filter(function(e){return /imei/i.test((e.name||'')+(e.id||'')+(e.placeholder||'')+(e.className||''));})[0]||list[0];"
                + "if(!el)return 'no_input';"
                + "el.focus();"
                + "var proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;"
                + "Object.getOwnPropertyDescriptor(proto,'value').set.call(el,v);"
                + "el.dispatchEvent(new Event('input',{bubbles:true}));"
                + "el.dispatchEvent(new Event('change',{bubbles:true}));"
                + "return 'ok';"
                + "})(" + JSONObject.quote(imei) + ")";

        webView.evaluateJavascript(js, result -> {
            if (result != null && result.contains("ok")) {
                Toast.makeText(this, "IMEI: " + imei, Toast.LENGTH_SHORT).show();
            } else {
                // Поле не найдено — копируем в буфер обмена
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("IMEI", imei));
                Toast.makeText(this,
                        "Поле ввода не найдено. IMEI " + imei + " скопирован в буфер обмена.",
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    // ---------- Навигация ----------

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
