package kg.imei.scanner;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String HOME_URL = "https://imei.kg";
    private static final String HOST = "imei.kg";
    private static final int MAX_FILL_ATTEMPTS = 15;   // 15 * 400 мс = 6 секунд ожидания поля ввода

    private WebView webView;
    private ProgressBar progressBar;
    private final Handler handler = new Handler(Looper.getMainLooper());

    /** IMEI, который нужно вставить и проверить, как только страница загрузится. */
    private String pendingImei = null;
    /** Язык сайта проверяется один раз при запуске приложения. */
    private boolean languageChecked = false;

    // Язык приложения и запросов WebView по умолчанию — русский
    @Override
    protected void attachBaseContext(Context base) {
        Locale ru = new Locale("ru", "RU");
        Locale.setDefault(ru);
        Configuration config = new Configuration(base.getResources().getConfiguration());
        config.setLocale(ru);
        super.attachBaseContext(base.createConfigurationContext(config));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);

        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        FrameLayout.LayoutParams pbParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(4));
        pbParams.gravity = Gravity.TOP;
        root.addView(progressBar, pbParams);

        Button scanButton = new Button(this);
        scanButton.setText("📷  Сканировать IMEI");
        scanButton.setAllCaps(false);
        scanButton.setTextColor(Color.WHITE);
        scanButton.setTextSize(16);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1565C0"));
        bg.setCornerRadius(dp(28));
        scanButton.setBackground(bg);
        scanButton.setPadding(dp(24), dp(12), dp(24), dp(12));
        scanButton.setElevation(dp(6));
        FrameLayout.LayoutParams btnParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, dp(56));
        btnParams.gravity = Gravity.BOTTOM | Gravity.END;
        btnParams.setMargins(dp(16), dp(16), dp(16), dp(24));
        root.addView(scanButton, btnParams);
        scanButton.setOnClickListener(v -> startScan());

        setContentView(root);

        setupWebView();

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
            languageChecked = true;
        } else {
            loadHome();
        }
    }

    /** Загружает главную страницу сайта с русским языком в заголовках запроса. */
    private void loadHome() {
        Map<String, String> headers = new HashMap<>();
        headers.put("Accept-Language", "ru-RU,ru;q=0.9");
        webView.loadUrl(HOME_URL, headers);
    }

    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && (host.equals(HOST) || host.endsWith("." + HOST))) {
                    return false; // остаёмся внутри приложения
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);

                if (pendingImei != null) {
                    // страница перезагружена после сканирования — вставляем IMEI и запускаем проверку
                    String imei = pendingImei;
                    pendingImei = null;
                    languageChecked = true;
                    fillImei(imei, 0);
                } else if (!languageChecked) {
                    languageChecked = true;
                    ensureRussian();
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress < 100 ? View.VISIBLE : View.GONE);
            }
        });
    }

    // ---------- Русский язык сайта по умолчанию ----------

    /** Если сайт открылся не на русском — нажимаем переключатель «RU / Русский». */
    private void ensureRussian() {
        String js = "(function(){"
                + "var l=(document.documentElement.lang||'').toLowerCase();"
                + "if(l.indexOf('ru')===0)return 'ru';"
                + "var re=/^(ru|rus|рус|русский|russian)$/i;"
                + "var t=[].slice.call(document.querySelectorAll('a,button,li,span,div,option')).filter(function(e){"
                + "return e.children.length===0&&re.test((e.textContent||'').trim());})[0];"
                + "if(!t)return 'none';"
                + "if(t.tagName==='OPTION'){var s=t.parentElement;if(s&&s.tagName==='OPTGROUP')s=s.parentElement;"
                + "if(s){s.value=t.value;s.dispatchEvent(new Event('change',{bubbles:true}));}}"
                + "else{t.click();}"
                + "return 'clicked';"
                + "})()";
        webView.evaluateJavascript(js, null);
    }

    // ---------- Сканер ----------

    private void startScan() {
        GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(
                        Barcode.FORMAT_CODE_128,
                        Barcode.FORMAT_CODE_39,
                        Barcode.FORMAT_CODE_93,
                        Barcode.FORMAT_EAN_13,
                        Barcode.FORMAT_EAN_8,
                        Barcode.FORMAT_ITF,
                        Barcode.FORMAT_UPC_A,
                        Barcode.FORMAT_QR_CODE,
                        Barcode.FORMAT_DATA_MATRIX,
                        Barcode.FORMAT_PDF417)
                .enableAutoZoom()
                .build();

        GmsBarcodeScanner scanner = GmsBarcodeScanning.getClient(this, options);
        scanner.startScan()
                .addOnSuccessListener(barcode -> onScanned(barcode.getRawValue()))
                .addOnCanceledListener(() -> { /* пользователь закрыл сканер */ })
                .addOnFailureListener(e -> Toast.makeText(this,
                        "Не удалось открыть сканер: " + e.getMessage()
                                + "\nПроверьте, что установлены Google Play services.",
                        Toast.LENGTH_LONG).show());
    }

    private void onScanned(String raw) {
        if (raw == null || raw.isEmpty()) {
            Toast.makeText(this, "Код не распознан", Toast.LENGTH_SHORT).show();
            return;
        }
        String imei = extractImei(raw);
        Toast.makeText(this, "IMEI: " + imei + " — проверяем…", Toast.LENGTH_SHORT).show();

        // Каждое новое сканирование начинает проверку заново:
        // перезагружаем страницу, затем в onPageFinished вставляем IMEI и жмём «Проверить»
        pendingImei = imei;
        loadHome();
    }

    /** Достаёт IMEI из значения штрихкода/QR. */
    private String extractImei(String raw) {
        // 1) ровно 15 цифр подряд (стандартный IMEI)
        Matcher m = Pattern.compile("(?<!\\d)\\d{15}(?!\\d)").matcher(raw);
        if (m.find()) return m.group();
        // 2) только цифры, если длина похожа на IMEI/IMEISV
        String digits = raw.replaceAll("\\D", "");
        if (digits.length() >= 14 && digits.length() <= 16) return digits;
        // 3) как есть
        return raw.trim();
    }

    /** Вставляет значение в поле ввода IMEI и нажимает «Проверить». Ждёт появления поля до 6 секунд. */
    private void fillImei(String imei, int attempt) {
        String js = "(function(v){"
                + "var list=[].slice.call(document.querySelectorAll('input,textarea')).filter(function(e){"
                + "var t=(e.type||'text').toLowerCase();"
                + "return ['text','tel','number','search',''].indexOf(t)>=0&&!e.disabled&&!e.readOnly&&e.offsetParent!==null;});"
                + "var el=list.filter(function(e){return /imei/i.test((e.name||'')+(e.id||'')+(e.placeholder||'')+(e.className||''));})[0]||list[0];"
                + "if(!el)return 'no_input';"
                + "el.focus();"
                + "var proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;"
                + "Object.getOwnPropertyDescriptor(proto,'value').set.call(el,v);"
                + "el.dispatchEvent(new Event('input',{bubbles:true}));"
                + "el.dispatchEvent(new Event('change',{bubbles:true}));"
                // Автоматически нажать кнопку «Проверить» (через 0.3 с, чтобы сайт успел принять значение)
                + "setTimeout(function(){"
                + "var f=function(r,s){return [].slice.call(r.querySelectorAll(s)).filter(function(b){"
                + "var t=String(b.innerText||b.value||b.textContent||'').toLowerCase();"
                + "return /проверить|проверка|проверь|check|найти|поиск|search|отправить|submit/.test(t)&&b.offsetParent!==null;})[0];};"
                + "var S='button,input[type=submit],input[type=button],[role=button]';"
                + "var btn=(el.form&&f(el.form,S))||f(document,S)||f(document,'a');"
                + "if(!btn&&el.form)btn=el.form.querySelector('button[type=submit],input[type=submit]');"
                + "if(btn){btn.click();}"
                + "else if(el.form){if(el.form.requestSubmit)el.form.requestSubmit();else el.form.submit();}"
                + "else{['keydown','keypress','keyup'].forEach(function(n){el.dispatchEvent(new KeyboardEvent(n,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));});}"
                + "},300);"
                + "return 'ok';"
                + "})(" + JSONObject.quote(imei) + ")";

        webView.evaluateJavascript(js, result -> {
            if (result != null && result.contains("ok")) {
                return; // поле найдено, проверка запущена
            }
            if (attempt < MAX_FILL_ATTEMPTS) {
                // страница ещё рисуется — пробуем снова
                handler.postDelayed(() -> fillImei(imei, attempt + 1), 400);
            } else {
                // Поле не найдено — копируем в буфер обмена
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("IMEI", imei));
                Toast.makeText(this,
                        "Поле ввода не найдено. IMEI " + imei + " скопирован в буфер обмена.",
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    // ---------- Навигация ----------

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
