package kg.imei.scanner;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;

/**
 * Полноэкранная анимация результата проверки:
 * зелёная галочка (зарегистрирован) или красный крестик (не зарегистрирован).
 * Рисуется поверх страницы и сама исчезает через ~2 секунды.
 */
public class ResultAnimationView extends View {

    private static final int GREEN = 0xFF2E7D32;
    private static final int RED = 0xFFD32F2F;
    private static final long DURATION_MS = 2000;

    private final Paint scrimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cardPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint markPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path checkPath = new Path();
    private final Path segment = new Path();
    private final RectF rect = new RectF();
    private final OvershootInterpolator overshoot = new OvershootInterpolator(2f);
    private final float d;

    private boolean positive;
    private String label = "";
    private float t = 0f;
    private ValueAnimator animator;

    public ResultAnimationView(Context context) {
        super(context);
        d = context.getResources().getDisplayMetrics().density;

        fillPaint.setStyle(Paint.Style.FILL);
        cardPaint.setStyle(Paint.Style.FILL);
        scrimPaint.setStyle(Paint.Style.FILL);

        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setStrokeWidth(8 * d);
        ringPaint.setStrokeCap(Paint.Cap.ROUND);

        markPaint.setStyle(Paint.Style.STROKE);
        markPaint.setStrokeWidth(9 * d);
        markPaint.setStrokeCap(Paint.Cap.ROUND);
        markPaint.setStrokeJoin(Paint.Join.ROUND);

        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextSize(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_SP, 19, context.getResources().getDisplayMetrics()));

        setVisibility(GONE);
    }

    /** Запускает анимацию. true — зелёная галочка, false — красный крестик. */
    public void play(boolean positive, String label) {
        this.positive = positive;
        this.label = label;
        if (animator != null) animator.cancel();
        t = 0f;
        setVisibility(VISIBLE);

        final ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        animator = a;
        a.setDuration(DURATION_MS);
        a.setInterpolator(new LinearInterpolator());
        a.addUpdateListener(va -> {
            t = (float) va.getAnimatedValue();
            invalidate();
        });
        a.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                if (animator == a) {
                    t = 0f;
                    setVisibility(GONE);
                }
            }
        });
        a.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (animator != null) animator.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (t <= 0f) return;

        float fade = t < 0.85f ? 1f : Math.max(0f, 1f - (t - 0.85f) / 0.15f);
        int w = getWidth();
        int h = getHeight();
        float cx = w / 2f;
        float cy = h / 2f;
        int color = positive ? GREEN : RED;

        // затемнение фона
        scrimPaint.setColor(withAlpha(Color.BLACK, 0.45f * fade));
        canvas.drawRect(0, 0, w, h, scrimPaint);

        // карточка с "выскакивающим" эффектом
        float scale = 0.75f + 0.25f * overshoot.getInterpolation(clamp(t / 0.18f));
        canvas.save();
        canvas.scale(scale, scale, cx, cy);

        float cardW = 250 * d;
        float cardH = 270 * d;
        rect.set(cx - cardW / 2, cy - cardH / 2, cx + cardW / 2, cy + cardH / 2);
        cardPaint.setColor(withAlpha(Color.WHITE, fade));
        canvas.drawRoundRect(rect, 28 * d, 28 * d, cardPaint);

        float ccy = cy - 22 * d;
        float r = 56 * d;
        float ringP = easeOut(clamp(t / 0.26f));
        float markP = easeOut(clamp((t - 0.24f) / 0.20f));

        // мягкая заливка круга
        fillPaint.setColor(withAlpha(color, 0.12f * markP * fade));
        canvas.drawCircle(cx, ccy, r, fillPaint);

        // кольцо, дорисовывающееся по кругу
        ringPaint.setColor(withAlpha(color, fade));
        rect.set(cx - r, ccy - r, cx + r, ccy + r);
        canvas.drawArc(rect, -90f, 360f * ringP, false, ringPaint);

        // галочка или крестик
        markPaint.setColor(withAlpha(color, fade));
        if (markP > 0f) {
            if (positive) {
                checkPath.reset();
                checkPath.moveTo(cx - 26 * d, ccy + 2 * d);
                checkPath.lineTo(cx - 8 * d, ccy + 20 * d);
                checkPath.lineTo(cx + 28 * d, ccy - 18 * d);
                PathMeasure pm = new PathMeasure(checkPath, false);
                segment.reset();
                pm.getSegment(0, pm.getLength() * markP, segment, true);
                canvas.drawPath(segment, markPaint);
            } else {
                float p1 = clamp(markP * 2f);
                float p2 = clamp(markP * 2f - 1f);
                float k = 22 * d;
                canvas.drawLine(cx - k, ccy - k,
                        cx - k + 2 * k * p1, ccy - k + 2 * k * p1, markPaint);
                if (p2 > 0f) {
                    canvas.drawLine(cx + k, ccy - k,
                            cx + k - 2 * k * p2, ccy - k + 2 * k * p2, markPaint);
                }
            }
        }

        // подпись
        textPaint.setColor(withAlpha(color, fade * markP));
        canvas.drawText(label, cx, ccy + r + 52 * d, textPaint);

        canvas.restore();
    }

    private static float clamp(float x) {
        return Math.max(0f, Math.min(1f, x));
    }

    private static float easeOut(float x) {
        float inv = 1f - x;
        return 1f - inv * inv * inv;
    }

    private static int withAlpha(int color, float a) {
        a = clamp(a);
        return Color.argb(Math.round(Color.alpha(color) * a),
                Color.red(color), Color.green(color), Color.blue(color));
    }
}
