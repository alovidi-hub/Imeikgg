package kg.imei.scanner;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class HistoryActivity extends Activity {

    private static final int BLUE = 0xFF1565C0;
    private static final int GREEN = 0xFF2E7D32;
    private static final int RED = 0xFFC62828;
    private static final int GRAY = 0xFF757575;

    private static final int REQ_EXPORT = 101;
    private static final int REQ_IMPORT = 102;

    private static final Locale RU = new Locale("ru", "RU");
    private final SimpleDateFormat dateTimeFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", RU);
    private final SimpleDateFormat dayFormat = new SimpleDateFormat("dd.MM.yyyy", RU);
    private final SimpleDateFormat dayKeyFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    private final SimpleDateFormat headerFormat = new SimpleDateFormat("EEEE, d MMMM yyyy", RU);
    private final SimpleDateFormat fileFormat = new SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US);

    /** Заголовок дня в списке. */
    private static class DayHeader {
        final String title;
        final int count;

        DayHeader(String title, int count) {
            this.title = title;
            this.count = count;
        }
    }

    private List<HistoryStore.Entry> all = new ArrayList<>();
    private final List<Object> rows = new ArrayList<>();   // DayHeader или Entry
    private int shownCount = 0;

    private boolean newestFirst = true;
    private long filterFrom = -1;   // начало выбранного периода (мс), -1 — фильтра нет
    private long filterTo = -1;     // конец выбранного периода (мс)
    private boolean exportCsv = false;

    private SharedPreferences ui;
    private HistoryAdapter adapter;
    private TextView emptyView;
    private TextView summaryView;
    private TextView resetView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BLUE);
        ui = getSharedPreferences("history_ui", MODE_PRIVATE);
        newestFirst = ui.getBoolean("newest_first", true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF5F5F5);

        // --- шапка: назад / заголовок / календарь / сортировка / меню ---
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(BLUE);
        header.setElevation(dp(4));
        header.setPadding(dp(4), dp(4), dp(4), dp(4));

        TextView back = headerButton("←", 26);
        back.setOnClickListener(v -> finish());
        header.addView(back);

        TextView title = new TextView(this);
        title.setText("История проверок");
        title.setTextColor(Color.WHITE);
        title.setTextSize(19);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView calendarBtn = headerButton("📅", 20);
        calendarBtn.setOnClickListener(v -> showFilterDialog());
        header.addView(calendarBtn);

        TextView sortBtn = headerButton("⇅", 22);
        sortBtn.setOnClickListener(v -> toggleSort());
        header.addView(sortBtn);

        TextView menuBtn = headerButton("⋮", 24);
        menuBtn.setOnClickListener(v -> showMenu(v));
        header.addView(menuBtn);

        root.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // --- строка со сводкой и сбросом фильтра ---
        LinearLayout summaryBar = new LinearLayout(this);
        summaryBar.setOrientation(LinearLayout.HORIZONTAL);
        summaryBar.setGravity(Gravity.CENTER_VERTICAL);
        summaryBar.setBackgroundColor(Color.WHITE);
        summaryBar.setPadding(dp(16), dp(2), dp(4), dp(2));

        summaryView = new TextView(this);
        summaryView.setTextColor(GRAY);
        summaryView.setTextSize(12);
        summaryView.setPadding(0, dp(8), 0, dp(8));
        summaryBar.addView(summaryView, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        resetView = new TextView(this);
        resetView.setText("✕ Сбросить");
        resetView.setTextColor(BLUE);
        resetView.setTextSize(13);
        resetView.setTypeface(Typeface.DEFAULT_BOLD);
        resetView.setPadding(dp(12), dp(8), dp(12), dp(8));
        resetView.setOnClickListener(v -> clearFilter());
        summaryBar.addView(resetView);

        root.addView(summaryBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // --- список ---
        FrameLayout content = new FrameLayout(this);

        ListView list = new ListView(this);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setPadding(0, dp(4), 0, dp(8));
        list.setClipToPadding(false);
        adapter = new HistoryAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            Object o = rows.get(position);
            if (o instanceof HistoryStore.Entry) showActions((HistoryStore.Entry) o);
        });
        content.addView(list, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        emptyView = new TextView(this);
        emptyView.setTextColor(GRAY);
        emptyView.setTextSize(16);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setPadding(dp(24), 0, dp(24), 0);
        content.addView(emptyView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        root.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        rebuild();
    }

    private TextView headerButton(String text, int sp) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(sp);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(8), dp(12), dp(8));
        return t;
    }

    // ---------- построение списка: фильтр по календарю → сортировка → группировка по дням ----------

    private void rebuild() {
        all = HistoryStore.load(this);

        List<HistoryStore.Entry> shown = new ArrayList<>();
        for (HistoryStore.Entry e : all) {
            if (filterFrom < 0 || (e.time >= filterFrom && e.time <= filterTo)) shown.add(e);
        }
        Collections.sort(shown, (a, b) -> newestFirst
                ? Long.compare(b.time, a.time)
                : Long.compare(a.time, b.time));

        Map<String, List<HistoryStore.Entry>> byDay = new LinkedHashMap<>();
        for (HistoryStore.Entry e : shown) {
            String k = dayKeyFormat.format(new Date(e.time));
            List<HistoryStore.Entry> g = byDay.get(k);
            if (g == null) {
                g = new ArrayList<>();
                byDay.put(k, g);
            }
            g.add(e);
        }

        rows.clear();
        for (List<HistoryStore.Entry> g : byDay.values()) {
            String t = headerFormat.format(new Date(g.get(0).time));
            if (!t.isEmpty()) t = t.substring(0, 1).toUpperCase(RU) + t.substring(1);
            rows.add(new DayHeader(t, g.size()));
            rows.addAll(g);
        }
        shownCount = shown.size();

        adapter.notifyDataSetChanged();
        updateSummary();
    }

    private void updateSummary() {
        boolean filtered = filterFrom >= 0;
        StringBuilder sb = new StringBuilder("Показано " + shownCount + " из " + all.size());
        if (filtered) sb.append(" · ").append(filterLabel());
        sb.append(" · ").append(newestFirst ? "сначала новые" : "сначала старые");
        summaryView.setText(sb.toString());
        resetView.setVisibility(filtered ? View.VISIBLE : View.GONE);

        if (shownCount == 0) {
            emptyView.setVisibility(View.VISIBLE);
            emptyView.setText(all.isEmpty()
                    ? "История пуста\nПроверенные IMEI появятся здесь"
                    : "Нет проверок за выбранный период");
        } else {
            emptyView.setVisibility(View.GONE);
        }
    }

    private String filterLabel() {
        String from = dayFormat.format(new Date(filterFrom));
        String to = dayFormat.format(new Date(filterTo));
        return from.equals(to) ? from : from + " – " + to;
    }

    // ---------- сортировка и календарь ----------

    private void toggleSort() {
        newestFirst = !newestFirst;
        ui.edit().putBoolean("newest_first", newestFirst).apply();
        Toast.makeText(this, newestFirst ? "Сначала новые" : "Сначала старые", Toast.LENGTH_SHORT).show();
        rebuild();
    }

    private void showFilterDialog() {
        List<String> options = new ArrayList<>(Arrays.asList(
                "Сегодня", "Вчера", "Выбрать день в календаре…", "Выбрать период в календаре…"));
        if (filterFrom >= 0) options.add("Сбросить фильтр");

        new AlertDialog.Builder(this)
                .setTitle("Фильтр по дате")
                .setItems(options.toArray(new String[0]), (dialog, which) -> {
                    long now = System.currentTimeMillis();
                    if (which == 0) {
                        setRange(now, now);
                    } else if (which == 1) {
                        setRange(now - 24L * 60 * 60 * 1000, now - 24L * 60 * 60 * 1000);
                    } else if (which == 2) {
                        pickDay();
                    } else if (which == 3) {
                        pickRange();
                    } else {
                        clearFilter();
                    }
                })
                .show();
    }

    private void setRange(long from, long to) {
        filterFrom = startOfDay(from);
        filterTo = endOfDay(to);
        rebuild();
    }

    private void clearFilter() {
        filterFrom = -1;
        filterTo = -1;
        rebuild();
    }

    private void pickDay() {
        Calendar c = Calendar.getInstance();
        DatePickerDialog dlg = new DatePickerDialog(this, (view, y, m, d) -> {
            Calendar sel = Calendar.getInstance();
            sel.set(y, m, d, 12, 0, 0);
            setRange(sel.getTimeInMillis(), sel.getTimeInMillis());
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        limitDates(dlg, -1);
        dlg.show();
    }

    private void pickRange() {
        final long[] start = new long[1];
        Calendar c = Calendar.getInstance();

        DatePickerDialog first = new DatePickerDialog(this, (view, y, m, d) -> {
            Calendar s = Calendar.getInstance();
            s.set(y, m, d, 12, 0, 0);
            start[0] = startOfDay(s.getTimeInMillis());

            Toast.makeText(this, "Теперь выберите конец периода", Toast.LENGTH_SHORT).show();
            Calendar now = Calendar.getInstance();
            DatePickerDialog second = new DatePickerDialog(this, (v2, y2, m2, d2) -> {
                Calendar e = Calendar.getInstance();
                e.set(y2, m2, d2, 12, 0, 0);
                setRange(start[0], e.getTimeInMillis());
            }, y, m, d);
            limitDates(second, start[0]);
            second.show();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        limitDates(first, -1);
        first.show();
    }

    /** Календарь: нельзя выбрать будущее и дни раньше самой первой проверки (или начала периода). */
    private void limitDates(DatePickerDialog dlg, long minOverride) {
        long max = System.currentTimeMillis();
        long min = minOverride;
        if (min < 0 && !all.isEmpty()) {
            long oldest = Long.MAX_VALUE;
            for (HistoryStore.Entry e : all) oldest = Math.min(oldest, e.time);
            min = startOfDay(oldest);
        }
        if (min >= 0 && min <= max) dlg.getDatePicker().setMinDate(min);
        dlg.getDatePicker().setMaxDate(max);
    }

    private static long startOfDay(long t) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(t);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private static long endOfDay(long t) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(startOfDay(t));
        c.add(Calendar.DAY_OF_MONTH, 1);
        return c.getTimeInMillis() - 1;
    }

    // ---------- меню: экспорт / импорт / очистка ----------

    private void showMenu(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenu().add(0, 1, 0, "Экспорт (JSON)");
        menu.getMenu().add(0, 2, 1, "Экспорт (CSV для Excel)");
        menu.getMenu().add(0, 3, 2, "Импорт из файла");
        menu.getMenu().add(0, 4, 3, "Очистить историю");
        menu.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1:
                    startExport(false);
                    return true;
                case 2:
                    startExport(true);
                    return true;
                case 3:
                    startImport();
                    return true;
                case 4:
                    confirmClear();
                    return true;
                default:
                    return false;
            }
        });
        menu.show();
    }

    private void startExport(boolean csv) {
        if (HistoryStore.load(this).isEmpty()) {
            Toast.makeText(this, "История пуста — экспортировать нечего", Toast.LENGTH_SHORT).show();
            return;
        }
        exportCsv = csv;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(csv ? "text/csv" : "application/json");
        i.putExtra(Intent.EXTRA_TITLE,
                "imei-history-" + fileFormat.format(new Date()) + (csv ? ".csv" : ".json"));
        startActivityForResult(i, REQ_EXPORT);
    }

    private void startImport() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_IMPORT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_EXPORT) {
            doExport(uri);
        } else if (requestCode == REQ_IMPORT) {
            doImport(uri);
        }
    }

    private void doExport(Uri uri) {
        List<HistoryStore.Entry> list = HistoryStore.load(this);
        String content = exportCsv ? toCsv(list) : HistoryStore.toJson(list);
        try (OutputStream os = getContentResolver().openOutputStream(uri, "wt")) {
            if (os == null) throw new IOException("stream is null");
            os.write(content.getBytes(StandardCharsets.UTF_8));
            Toast.makeText(this, "Экспортировано записей: " + list.size(), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось сохранить файл", Toast.LENGTH_LONG).show();
        }
    }

    private void doImport(Uri uri) {
        try (InputStream is = getContentResolver().openInputStream(uri)) {
            if (is == null) throw new IOException("stream is null");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
            String text = new String(bos.toByteArray(), StandardCharsets.UTF_8);

            List<HistoryStore.Entry> incoming = HistoryStore.fromJson(text);
            int added = HistoryStore.merge(this, incoming);
            int skipped = incoming.size() - added;
            Toast.makeText(this, "Импортировано: " + added
                            + (skipped > 0 ? ", пропущено дубликатов: " + skipped : ""),
                    Toast.LENGTH_LONG).show();
            rebuild();
        } catch (Exception e) {
            Toast.makeText(this,
                    "Не удалось импортировать. Нужен JSON-файл, ранее экспортированный из приложения.",
                    Toast.LENGTH_LONG).show();
        }
    }

    /** CSV с разделителем «;» и BOM — корректно открывается в Excel на русском языке. */
    private String toCsv(List<HistoryStore.Entry> list) {
        StringBuilder sb = new StringBuilder("﻿");
        sb.append("Дата и время;IMEI;Результат;Производитель;Ответ сайта\r\n");
        for (HistoryStore.Entry e : list) {
            sb.append(csv(dateTimeFormat.format(new Date(e.time)))).append(';')
                    .append(csv("'" + e.imei)).append(';') // апостроф, чтобы Excel не превратил IMEI в число
                    .append(csv(statusText(e.status))).append(';')
                    .append(csv(e.brand)).append(';')
                    .append(csv(e.text)).append("\r\n");
        }
        return sb.toString();
    }

    private static String csv(String s) {
        if (s == null) s = "";
        return "\"" + s.replace("\"", "\"\"").replace('\n', ' ') + "\"";
    }

    private static String statusText(int status) {
        if (status == HistoryStore.STATUS_REGISTERED) return "Зарегистрирован";
        if (status == HistoryStore.STATUS_NOT_REGISTERED) return "Не зарегистрирован";
        return "Не определено";
    }

    // ---------- действия над записью ----------

    private void showActions(HistoryStore.Entry e) {
        String[] actions = {"Проверить снова", "Копировать IMEI", "Указать производителя…", "Удалить запись"};
        new AlertDialog.Builder(this)
                .setTitle(e.imei)
                .setItems(actions, (dialog, which) -> {
                    if (which == 0) {
                        Intent i = new Intent(this, MainActivity.class);
                        i.putExtra(MainActivity.EXTRA_RECHECK_IMEI, e.imei);
                        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        startActivity(i);
                        finish();
                    } else if (which == 1) {
                        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("IMEI", e.imei));
                        Toast.makeText(this, "IMEI скопирован", Toast.LENGTH_SHORT).show();
                    } else if (which == 2) {
                        pickBrand(e);
                    } else {
                        HistoryStore.remove(this, e);
                        rebuild();
                    }
                })
                .show();
    }

    private void pickBrand(HistoryStore.Entry e) {
        List<String> names = Brands.names();
        List<String> items = new ArrayList<>(names);
        items.add("Не указан");
        new AlertDialog.Builder(this)
                .setTitle("Производитель")
                .setItems(items.toArray(new String[0]), (dialog, which) -> {
                    e.brand = which < names.size() ? names.get(which) : "";
                    HistoryStore.update(this, e);
                    rebuild();
                })
                .show();
    }

    private void confirmClear() {
        new AlertDialog.Builder(this)
                .setTitle("Очистить историю?")
                .setMessage("Все записи будут удалены без возможности восстановления. "
                        + "Если нужна копия — сначала сделайте экспорт.")
                .setPositiveButton("Очистить", (d, w) -> {
                    HistoryStore.clear(this);
                    rebuild();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    // ---------- адаптер ----------

    private static class Holder {
        TextView badge;
        TextView imei;
        TextView status;
        TextView meta;
        TextView note;
    }

    private class HistoryAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return rows.size();
        }

        @Override
        public Object getItem(int position) {
            return rows.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public int getViewTypeCount() {
            return 2;
        }

        @Override
        public int getItemViewType(int position) {
            return rows.get(position) instanceof DayHeader ? 0 : 1;
        }

        @Override
        public boolean areAllItemsEnabled() {
            return false;
        }

        @Override
        public boolean isEnabled(int position) {
            return rows.get(position) instanceof HistoryStore.Entry;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Object o = rows.get(position);

            if (o instanceof DayHeader) {
                DayHeader h = (DayHeader) o;
                TextView t = (TextView) convertView;
                if (t == null) {
                    t = new TextView(HistoryActivity.this);
                    t.setTextSize(13);
                    t.setTypeface(Typeface.DEFAULT_BOLD);
                    t.setTextColor(0xFF455A64);
                    t.setPadding(dp(18), dp(14), dp(16), dp(4));
                }
                t.setText(h.title + "  ·  " + h.count);
                return t;
            }

            if (convertView == null) convertView = buildRow();
            Holder h = (Holder) convertView.getTag();
            HistoryStore.Entry e = (HistoryStore.Entry) o;

            applyBadge(h.badge, e.brand);
            h.imei.setText(e.imei);

            if (e.status == HistoryStore.STATUS_REGISTERED) {
                h.status.setText("✔ " + statusText(e.status));
                h.status.setTextColor(GREEN);
            } else if (e.status == HistoryStore.STATUS_NOT_REGISTERED) {
                h.status.setText("✖ " + statusText(e.status));
                h.status.setTextColor(RED);
            } else {
                h.status.setText("? " + statusText(e.status));
                h.status.setTextColor(GRAY);
            }

            String brand = (e.brand == null || e.brand.isEmpty()) ? "" : e.brand + " · ";
            h.meta.setText(brand + dateTimeFormat.format(new Date(e.time)));

            String note = e.text == null ? "" : e.text.replace('\n', ' ').trim();
            h.note.setText(note);
            h.note.setVisibility(note.isEmpty() ? View.GONE : View.VISIBLE);
            return convertView;
        }
    }

    /** Значок производителя: цветной кружок с короткой меткой; для неизвестного — серый со смартфоном. */
    private void applyBadge(TextView tv, String brandName) {
        Brands.Brand b = Brands.get(brandName);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        if (b == null) {
            g.setColor(0xFFECEFF1);
            tv.setText("📱");
            tv.setTextColor(0xFF607D8B);
            tv.setTextSize(20);
        } else {
            g.setColor(b.color);
            tv.setText(b.label);
            tv.setTextColor(b.textColor);
            tv.setTextSize(b.label.length() >= 2 ? 15 : 19);
        }
        tv.setBackground(g);
    }

    private View buildRow() {
        LinearLayout outer = new LinearLayout(this);
        outer.setPadding(dp(12), dp(5), dp(12), dp(5));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(12), dp(12), dp(16), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), 0xFFE0E0E0);
        card.setBackground(bg);
        outer.addView(card, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Holder h = new Holder();

        h.badge = new TextView(this);
        h.badge.setGravity(Gravity.CENTER);
        h.badge.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(46), dp(46));
        bp.setMargins(0, 0, dp(12), 0);
        card.addView(h.badge, bp);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        card.addView(col, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        h.imei = new TextView(this);
        h.imei.setTextColor(0xFF212121);
        h.imei.setTextSize(17);
        h.imei.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(h.imei);

        h.status = new TextView(this);
        h.status.setTextSize(13);
        h.status.setTypeface(Typeface.DEFAULT_BOLD);
        h.status.setPadding(0, dp(2), 0, 0);
        col.addView(h.status);

        h.meta = new TextView(this);
        h.meta.setTextColor(GRAY);
        h.meta.setTextSize(12);
        h.meta.setPadding(0, dp(3), 0, 0);
        col.addView(h.meta);

        h.note = new TextView(this);
        h.note.setTextColor(0xFF9E9E9E);
        h.note.setTextSize(12);
        h.note.setMaxLines(2);
        h.note.setEllipsize(TextUtils.TruncateAt.END);
        h.note.setPadding(0, dp(3), 0, 0);
        col.addView(h.note);

        outer.setTag(h);
        return outer;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
