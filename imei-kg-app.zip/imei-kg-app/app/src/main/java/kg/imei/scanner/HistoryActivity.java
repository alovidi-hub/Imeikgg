package kg.imei.scanner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HistoryActivity extends Activity {

    private static final int BLUE = 0xFF1565C0;
    private static final int GREEN = 0xFF2E7D32;
    private static final int RED = 0xFFC62828;
    private static final int GRAY = 0xFF757575;

    private final SimpleDateFormat dateFormat =
            new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", new Locale("ru", "RU"));

    private List<HistoryStore.Entry> items = new ArrayList<>();
    private HistoryAdapter adapter;
    private TextView emptyView;
    private TextView clearButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BLUE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF5F5F5);

        // --- шапка ---
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(BLUE);
        header.setElevation(dp(4));
        header.setPadding(dp(4), dp(4), dp(4), dp(4));

        TextView back = new TextView(this);
        back.setText("←");
        back.setTextColor(Color.WHITE);
        back.setTextSize(26);
        back.setPadding(dp(14), dp(8), dp(14), dp(8));
        back.setOnClickListener(v -> finish());
        header.addView(back);

        TextView title = new TextView(this);
        title.setText("История проверок");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        clearButton = new TextView(this);
        clearButton.setText("Очистить");
        clearButton.setTextColor(Color.WHITE);
        clearButton.setTextSize(14);
        clearButton.setPadding(dp(14), dp(10), dp(14), dp(10));
        clearButton.setOnClickListener(v -> confirmClear());
        header.addView(clearButton);

        root.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // --- список ---
        FrameLayout content = new FrameLayout(this);

        ListView list = new ListView(this);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setPadding(0, dp(6), 0, dp(6));
        list.setClipToPadding(false);
        adapter = new HistoryAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> showActions(items.get(position)));
        content.addView(list, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        emptyView = new TextView(this);
        emptyView.setText("История пуста\nПроверенные IMEI появятся здесь");
        emptyView.setTextColor(GRAY);
        emptyView.setTextSize(16);
        emptyView.setGravity(Gravity.CENTER);
        content.addView(emptyView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        root.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        refresh();
    }

    private void refresh() {
        items = HistoryStore.load(this);
        adapter.notifyDataSetChanged();
        boolean empty = items.isEmpty();
        emptyView.setVisibility(empty ? View.VISIBLE : View.GONE);
        clearButton.setVisibility(empty ? View.INVISIBLE : View.VISIBLE);
    }

    private void showActions(HistoryStore.Entry e) {
        String[] actions = {"Проверить снова", "Копировать IMEI", "Удалить запись"};
        new AlertDialog.Builder(this)
                .setTitle(e.imei)
                .setItems(actions, (dialog, which) -> {
                    if (which == 0) {
                        Intent i = new Intent(this, MainActivity.class);
                        i.putExtra(MainActivity.EXTRA_RECHECK_IMEI, e.imei);
                        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        startActivity(i);
                        finish();
                    } else if (which == 1) {
                        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("IMEI", e.imei));
                        Toast.makeText(this, "IMEI скопирован", Toast.LENGTH_SHORT).show();
                    } else {
                        HistoryStore.remove(this, e);
                        refresh();
                    }
                })
                .show();
    }

    private void confirmClear() {
        new AlertDialog.Builder(this)
                .setTitle("Очистить историю?")
                .setMessage("Все записи будут удалены без возможности восстановления.")
                .setPositiveButton("Очистить", (d, w) -> {
                    HistoryStore.clear(this);
                    refresh();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    // ---------- адаптер ----------

    private static class Holder {
        TextView imei;
        TextView status;
        TextView date;
        TextView note;
    }

    private class HistoryAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) convertView = buildRow();
            Holder h = (Holder) convertView.getTag();
            HistoryStore.Entry e = items.get(position);

            h.imei.setText(e.imei);
            h.date.setText(dateFormat.format(new Date(e.time)));

            if (e.status == HistoryStore.STATUS_REGISTERED) {
                h.status.setText("✔ Зарегистрирован");
                h.status.setTextColor(GREEN);
            } else if (e.status == HistoryStore.STATUS_NOT_REGISTERED) {
                h.status.setText("✖ Не зарегистрирован");
                h.status.setTextColor(RED);
            } else {
                h.status.setText("? Не определено");
                h.status.setTextColor(GRAY);
            }

            String note = e.text == null ? "" : e.text.replace('\n', ' ').trim();
            h.note.setText(note);
            h.note.setVisibility(note.isEmpty() ? View.GONE : View.VISIBLE);
            return convertView;
        }
    }

    private View buildRow() {
        LinearLayout outer = new LinearLayout(this);
        outer.setPadding(dp(12), dp(5), dp(12), dp(5));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(12), dp(16), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), 0xFFE0E0E0);
        card.setBackground(bg);
        outer.addView(card, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        Holder h = new Holder();

        h.imei = new TextView(this);
        h.imei.setTextColor(0xFF212121);
        h.imei.setTextSize(18);
        h.imei.setTypeface(Typeface.DEFAULT_BOLD);
        top.addView(h.imei, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        h.status = new TextView(this);
        h.status.setTextSize(13);
        h.status.setTypeface(Typeface.DEFAULT_BOLD);
        h.status.setPadding(dp(8), 0, 0, 0);
        top.addView(h.status);

        card.addView(top, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        h.date = new TextView(this);
        h.date.setTextColor(GRAY);
        h.date.setTextSize(13);
        h.date.setPadding(0, dp(4), 0, 0);
        card.addView(h.date);

        h.note = new TextView(this);
        h.note.setTextColor(0xFF9E9E9E);
        h.note.setTextSize(12);
        h.note.setMaxLines(2);
        h.note.setEllipsize(TextUtils.TruncateAt.END);
        h.note.setPadding(0, dp(4), 0, 0);
        card.addView(h.note);

        outer.setTag(h);
        return outer;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
